package hellojpa;

public class RoleType {
    
}
